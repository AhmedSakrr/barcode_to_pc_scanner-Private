Barcode to PC Scanner Client

EN: Software for scaning Barcodes and QR form Smartphone direct to PC.

RU: Программа для сканирования штрихкодов и QR сразу в компьютер или в файл Excel на телефоне.

https://prime-soft.biz/products/barcode-scanner
